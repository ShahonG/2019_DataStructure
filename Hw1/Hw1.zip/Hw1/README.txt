To run this code on Terminal：
	1.move to the directory
	2.type gcc KMP.c -o kmp
	3.type ./kmp

Enter the Inputs：
	1.Input the ciphertext
	2.Input the article.txt
	3.Input the answer_dic