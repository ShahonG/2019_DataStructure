Compile and Run:
    1. gcc 5-1.c -o 5-1 (replace 5-1 by 5-2 and 5-3)
    2. Give input by each assignment

5-1 (Kruskal):
    Minimal spanning tree , find the smallest cost

5-2 (Dijkstra):
    Very similar to DP

5-3 (articulation point):
    I have lots of problem when coding , because I'm not clear about low array , I search lots of information on internet , and I will post my reference below.
http://www.csie.ntnu.edu.tw/~u91029/Component.html