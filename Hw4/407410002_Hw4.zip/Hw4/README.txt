Run hw4-1:
    1. Compile 'DS_hw2-1.c' by "gcc DS_hw4-1.c -o 4.1"
    2. Run "./4.1"
    3. Give input according to assignment 4.1

Run hw4-2:
    1. Compile 'DS_hw4-2.c' by "gcc DS_hw4-2.c -o 4.2"
    2. Run "./4.2"
    3. Give input according to assignment 4.2