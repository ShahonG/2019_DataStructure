Run hw2-2:
    1. Compile 'DS_hw2-1.c' by "gcc DS_hw2-1.c -o DS_hw2.1"
    2. Run "./DS_hw2.1"

Run hw2-2:
    1. Compile 'DS_hw2-2.c' by "gcc DS_hw2-2.c -o DS_hw2.2"
    2. Run "./DS_hw2.2"
