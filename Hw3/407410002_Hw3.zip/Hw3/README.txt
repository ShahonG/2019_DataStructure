Compile：
	gcc Hw3.c -o hw3
Run：
	./hw3
input：
	first line of input is counter_clockwise
	second is direction of elimination
	third is the number of skip(move Head position)
	and after is elimination game's player name.

output：
	First line of output is player's name
	second line is player's name with odd-even position
	third line is player's name after rotate the circular linked-list
	after these three line is elimination game