Compile and Run:
    1. gcc 6-1.c -o 6-1 (replace 6-1 by 6-2 and 6-3 and 6-4)
    2. Give input by each assignment

6-1 (Slection Sort):
    Pick largest number of array and put it in the front of unsorted array.

6-2 (Insertion Sort):
    Insert first element of unsorted array into sorted array and move every element behind to element+1's position.   

6-3 (Merge Sort):
    Because of the example output , I replace recursive by loop , and First Loop is about the range I want to Sort , and Second Loop is about the left point , 2*range is because you will have a mid point to split data.

6-4 (Bucket Sort):
    Use first number of string to store data into bucket , and I use bubble sort to sort each bucket because bubble sort is easier to coding.